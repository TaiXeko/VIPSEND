<?php
namespace EkkoVN\VIPSEND;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\{Command, CommandSender, ConsoleCommandSender};
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\level\sound\ClickSound;

class Main extends PluginBase implements Listener{
    
    
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveDefaultConfig();
		$this->getLogger()->info(TEXTFORMAT::GREEN . "VIPSEND-EKKO LOAD ");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        $cmd = strtolower($command->getName());
        switch ($cmd){
            case "vip":
                if (!($sender instanceof Player)){
                	
                     } else {
                    $sender->sendMessage(TextFormat::YELLOW . "--------[" . $this->getConfig()->get("VIP1") . "]--------");
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip1"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip2"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip3"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip4"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip5"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip6"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip7"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("vip8"));
                    $sender->sendMessage("§e- Copyright © Ekko: " . $this->getConfig()->get("website"));
                    return true;
                }
            case "rules":
                if (!($sender instanceof Player)){
                	    } else {
                    $sender->sendMessage(TextFormat::YELLOW . "--------[" . $this->getConfig()->get("nameserver") . "]--------");
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules1"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules2"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules3"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules4"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules5"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules6"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules7"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("rules8"));
                    return true;
                }

            case "staff":
                if (!($sender instanceof Player)){
                	    } else {
                    $sender->sendMessage(TextFormat::YELLOW . "--------[" . $this->getConfig()->get("nameserver") . "]--------");
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff1"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff2"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff3"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff4"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff5"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff6"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff7"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("staff8"));   
                    
                    return true;
                }
                
            case "info":
                if (!($sender instanceof Player)){
                	    } else {
                    $sender->sendMessage(TextFormat::YELLOW . "--------[" . $this->getConfig()->get("nameserver") . "]--------");
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info1"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info2"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info3"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info4"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info5"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info6"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info7"));
                    $sender->sendMessage("§e- " . $this->getConfig()->get("info8"));   
                    $sender->sendMessage("Ekko" . $this->getConfig()->get("facebook"));
                    return true;
                }
             case "ping":
                if (!($sender instanceof Player)){
                	    } else {
        
                    $sender->sendMessage(TextFormat::YELLOW . "Pong");
                    
                    return true;
                }
          
			
                break;
            }
        }
    }
?>